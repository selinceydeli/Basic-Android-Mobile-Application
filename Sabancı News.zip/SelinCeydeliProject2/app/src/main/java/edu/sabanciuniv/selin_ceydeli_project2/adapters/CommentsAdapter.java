package edu.sabanciuniv.selin_ceydeli_project2.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.sabanciuniv.selin_ceydeli_project2.R;
import edu.sabanciuniv.selin_ceydeli_project2.models.Comments;

public class CommentsAdapter extends RecyclerView.Adapter<CommentsAdapter.CommentsViewHolder>{

    Context ctx;
    List<Comments> data;

    public CommentsAdapter(Context ctx, List<Comments> data) {
        this.ctx = ctx;
        this.data = data;
    }

    //Creating a method to set the data for the adapter and update the data field
    public void setData(List<Comments> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public CommentsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(ctx).inflate(R.layout.comments_row_layout,parent,false);
        CommentsViewHolder holder = new CommentsViewHolder(root);
        holder.setIsRecyclable(false);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CommentsViewHolder holder, int position) {
        holder.txtOwner.setText(data.get(position).getOwnerName());
        holder.txtCommentByOwner.setText(data.get(position).getMessage());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class CommentsViewHolder extends RecyclerView.ViewHolder {
        TextView txtOwner;
        TextView txtCommentByOwner;
        ConstraintLayout row;

        public CommentsViewHolder(@NonNull View itemView) {
            super(itemView);
            txtOwner = itemView.findViewById(R.id.txtOwnerName);
            txtCommentByOwner = itemView.findViewById(R.id.txtCommentByOwner);
            row = itemView.findViewById(R.id.rowComment);
        }
    }
}
