package edu.sabanciuniv.selin_ceydeli_project2.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import edu.sabanciuniv.selin_ceydeli_project2.R;
import edu.sabanciuniv.selin_ceydeli_project2.models.News;

public class NewsDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_detail);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //make the back button icon clickable

        //Catching the intent
        News selected = (News)getIntent().getSerializableExtra("selectedRow");

        //Changing the action bar title in the Activity Details
        String newsType = selected.getNewsType();
        getSupportActionBar().setTitle(newsType);

        //Setting the information from the news I selected
        ImageView img = findViewById(R.id.newsImage);
        img.setImageResource(selected.getImg());

        TextView title = findViewById(R.id.newsTitle);
        title.setText(String.valueOf(selected.getTitle()));

        TextView text = findViewById(R.id.newsText);
        text.setText(String.valueOf(selected.getText()));

        TextView date = findViewById(R.id.newsDate);
        date.setText(String.valueOf(selected.getDate()));
    }

    //Defining a menu button to navigate to Comments activity
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.show_comments_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handling action bar item clicks here.
        int id = item.getItemId();
        News selected = (News)getIntent().getSerializableExtra("selectedRow");
        if (id == R.id.action_show_comments) {
            Intent intent = new Intent(this, CommentsActivity.class);
            intent.putExtra("selectedNews",selected); //sending News object to the Comments activity
            startActivity(intent);
            return true;
        }
        // Enabling the back button activity
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}