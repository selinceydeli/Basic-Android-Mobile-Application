package edu.sabanciuniv.selin_ceydeli_project2.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.concurrent.ExecutorService;

import edu.sabanciuniv.selin_ceydeli_project2.MyApplication;
import edu.sabanciuniv.selin_ceydeli_project2.MyRepository;
import edu.sabanciuniv.selin_ceydeli_project2.R;
import edu.sabanciuniv.selin_ceydeli_project2.adapters.CommentsAdapter;
import edu.sabanciuniv.selin_ceydeli_project2.models.Comments;
import edu.sabanciuniv.selin_ceydeli_project2.models.News;

public class PostCommentActivity extends AppCompatActivity {

    ProgressBar prg;
    EditText txtName;
    EditText txtComment;
    TextView txtMessageDisplay;
    News selected;

    //Data handler for posting comments
    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            if (msg.what == MyRepository.SUCCESS) {
                return true;
            } else {
                return false;
            }
        }
    });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_comment);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //make the back button icon clickable

        //Changing the action bar title in the Main Activity
        getSupportActionBar().setTitle("Post Comment");

        //Catching the intent
        selected = (News)getIntent().getSerializableExtra("selectedNewsToPostComment");

        //Enabling progress bar
        prg = findViewById(R.id.progressBarPost);

        txtName = findViewById(R.id.txtName);
        txtComment = findViewById(R.id.txtComment);
        Button btnPostComment = findViewById(R.id.btnPostComment);

        btnPostComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Show the progress bar while processing the data
                prg.setVisibility(View.VISIBLE);
                String name = txtName.getText().toString();
                String text = txtComment.getText().toString();
                String news_id = String.valueOf(selected.getId());
                if ( text.isEmpty() || name.isEmpty() ) {
                    txtMessageDisplay = findViewById(R.id.txtFailMessage);
                    txtMessageDisplay.setText("Enter valid input");
                    txtMessageDisplay.setVisibility(View.VISIBLE);
                }
                else {
                    ExecutorService srv = ((MyApplication) getApplication()).srv;
                    MyRepository repo = new MyRepository();
                    repo.saveComment(srv, dataHandler, name, text, news_id);
                    Intent i = new Intent(PostCommentActivity.this, CommentsActivity.class);
                    //Catching the intent
                    selected = (News)getIntent().getSerializableExtra("selectedNewsToPostComment");
                    i.putExtra("selectedNews", selected);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                }
                //Make the progress bar hidden after the data inputted by the user is processed
                prg.setVisibility(View.INVISIBLE);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Enabling the back button activity
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
