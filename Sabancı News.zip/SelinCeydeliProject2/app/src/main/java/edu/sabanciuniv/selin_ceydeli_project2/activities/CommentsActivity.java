package edu.sabanciuniv.selin_ceydeli_project2.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

import edu.sabanciuniv.selin_ceydeli_project2.MyApplication;
import edu.sabanciuniv.selin_ceydeli_project2.MyRepository;
import edu.sabanciuniv.selin_ceydeli_project2.R;
import edu.sabanciuniv.selin_ceydeli_project2.adapters.CommentsAdapter;
import edu.sabanciuniv.selin_ceydeli_project2.models.Comments;
import edu.sabanciuniv.selin_ceydeli_project2.models.News;

public class CommentsActivity extends AppCompatActivity {

    ProgressBar prg;
    RecyclerView recView;
    News selected;

    Handler dataHandler2 = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<Comments> data = (List<Comments>)msg.obj;
            CommentsAdapter adp = new CommentsAdapter(CommentsActivity.this,data);
            recView.setAdapter(adp);
            recView.setVisibility(View.VISIBLE);
            prg.setVisibility(View.INVISIBLE);
            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //make the back button icon clickable

        //Changing the action bar title in the Comments Activity
        getSupportActionBar().setTitle("Comments");

        //Catching the intent
        selected = (News)getIntent().getSerializableExtra("selectedNews");

        //Enabling progress bar
        prg = findViewById(R.id.progressBar);
        recView = findViewById(R.id.recyclerViewList); //calling a reference to recycler view
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recView.setLayoutManager(layoutManager); //setting a layout manager to display data in rows
        recView.setHasFixedSize(true);

        prg.setVisibility(View.VISIBLE);
        recView.setVisibility(View.INVISIBLE);

        MyRepository repo = new MyRepository();
        repo.getCommentsByNewsId(((MyApplication)getApplication()).srv, dataHandler2, String.valueOf(selected.getId()));
    }

    //Defining a menu button to navigate to Post Comments activity
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.post_comment_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handling action bar item clicks here.
        int id = item.getItemId();
        selected = (News)getIntent().getSerializableExtra("selectedNews");
        if (id == R.id.action_post_comments) {
            Intent intent = new Intent(this, PostCommentActivity.class);
            intent.putExtra("selectedNewsToPostComment",selected);
            startActivity(intent);
            return true;
        }
        // Enabling the back button activity
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
