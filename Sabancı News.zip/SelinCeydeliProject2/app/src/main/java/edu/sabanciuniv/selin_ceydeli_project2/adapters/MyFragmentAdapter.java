package edu.sabanciuniv.selin_ceydeli_project2.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import edu.sabanciuniv.selin_ceydeli_project2.fragments.EducationFragment;
import edu.sabanciuniv.selin_ceydeli_project2.fragments.HealthFragment;
import edu.sabanciuniv.selin_ceydeli_project2.fragments.PoliticsFragment;
import edu.sabanciuniv.selin_ceydeli_project2.fragments.TechnologyFragment;

public class MyFragmentAdapter extends FragmentStateAdapter {

    public MyFragmentAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new PoliticsFragment();
            case 1:
                return new EducationFragment();
            case 2:
                return new TechnologyFragment();
            case 3:
                return new HealthFragment();
            default:
                return new PoliticsFragment();
        }
    }

    @Override
    public int getItemCount() {
        return 4;
    }

}
