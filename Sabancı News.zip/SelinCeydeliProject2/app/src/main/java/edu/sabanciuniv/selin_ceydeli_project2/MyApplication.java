package edu.sabanciuniv.selin_ceydeli_project2;

import android.app.Application;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyApplication extends Application {

    //Accessing the executor service
    public ExecutorService srv = Executors.newCachedThreadPool();
}
