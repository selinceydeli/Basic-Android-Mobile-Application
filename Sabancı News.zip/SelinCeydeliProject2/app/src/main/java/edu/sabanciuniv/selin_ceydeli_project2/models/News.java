package edu.sabanciuniv.selin_ceydeli_project2.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import edu.sabanciuniv.selin_ceydeli_project2.R;

public class News implements Serializable {

    private int id;
    private String title;
    private String text;
    private String date;
    private int img;
    private String newsType;

    //Default constructor
    public News() {}

    //Non-default constructor
    public News(int id, String title, String text, String date, int img, String newsType) {
        this.id = id;
        this.title = title;
        this.text = text;
        this.date = date;
        this.img = img;
        this.newsType = newsType;
    }

    public News(String title, String text, String date, int img, String newsType) {
        this.title = title;
        this.text = text;
        this.date = date;
        this.img = img;
        this.newsType = newsType;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getNewsType() { return newsType; }

    public void setNewsType(String newsType) { this.newsType = newsType; }

    public static List<News> getPoliticsNews() {

        List<News> newsArrayList = new ArrayList<>();

        //Politics
        News news1 = new News(1,"How Democracy Fought Back in 2022","The forces of representative government and fair elections " +
                "made critical progress around the world. And while the struggle is far from over, the wins provide " +
                "momentum that could be pivotal in world history.\n \nAcross America last year, election deniers were defeated in the " +
                "midterms elections, and President Joe Biden recently signed legislation shoring up the nation's presidential " +
                "election certification system. Seemingly against all odds, Ukraine has managed to hold off Russian aggression. " +
                "And in Iran, China and Brazil, pro-democracy forces scored successes in standing up to authoritarian regimes.",
                "30/12/2022", R.drawable.news1_img,"Politics");
        newsArrayList.add(news1);

        //Politics
        News news2 = new News(2,"House Committee Releases Trump Tax Returns","The release will launch new scrutiny of the former " +
                "president’s finances and comes after he fought for years to keep the returns secret.\n \nThe Democratic-led House Ways " +
                "and Means committee released six years of former President Donald Trump’s tax returns on Friday, " +
                "marking the culmination of a nearly four-year investigation and a bruising legal battle that made it to the Supreme Court.",
                "30/12/2022",R.drawable.news2_img,"Politics");
        newsArrayList.add(news2);

        //Politics
        News news4 = new News(3,"Benedict Death Paves Way for Protocols to Guide Future Popes","The death of Pope Emeritus " +
                "Benedict XVI has unfolded in an entirely un-papal-like manner: There were no bells tolling in St. Peter's Basilica, " +
                "no solemn announcement in a Vatican City square and no mobilizing of official delegations to Rome.\n \nThe death of " +
                "Pope Emeritus Benedict XVI passed in an entirely un-papal-like manner Saturday, with a two-sentence announcement " +
                "from the Vatican press office, making clear once and for all that Benedict stopped being pope a decade ago. " +
                "The rituals of his passing were less like the ones of a pontiff, monarch or Vicar of Christ on Earth and more akin " +
                "to those of a retired bishop, even if he will be buried in the red vestments of a pope.",
                "1/1/2023",R.drawable.news4_img,"Politics");
        newsArrayList.add(news4);

        //Politics
        News news6 = new News(4,"Biden Issues Pardons Ahead of New Year", "Drug-related offenders – none of whom are currently incarcerated – " +
                "made up the majority of the recipients to whom the president issued pardons ahead of the new year.\n \nPresident Joe Biden pardoned " +
                "six individuals Friday – four of whom were convicted on drug charges, one who failed to pay a distilled spirits tax and one" +
                "who shot a husband who had abused her while she was pregnant.",
                "30/12/2022",R.drawable.news6_img,"Politics");
        newsArrayList.add(news6);

        //Politics
        News news8 = new News(5,"North Korea Enters 2023 With Clear Plan for Military Escalation","North Korea on Wednesday signaled that it " +
                "plans to escalate its weapons development and production – to include potential nuclear tests – at a time it senses weakness from " +
                "its adversaries in the region.\n \nAt the end of a year in which it test fired an unprecedented number of missiles, including those " +
                "capable of reaching U.S. territory, North Korean leader Kim Jong Un convened a meeting of the Workers’ Party congress during which he " +
                "disclosed new goals for 2023. He described to the elites in Pyongyang a “newly created challenging situation” on the Korean Peninsula " +
                "and the need for a new direction in the hermit kingdom’s anti-enemy struggle.",
                "28/12/2022",R.drawable.news8_img,"Politics");
        newsArrayList.add(news8);

        return newsArrayList;
    }

    public static List<News> getEducationNews() {

        List<News> newsArrayList = new ArrayList<>();

        //Education
        News news5 = new News(6,"What to Know About Unschooling", "A small minority of families have always sought alternatives " +
                "to traditional public schools in the U.S. But the COVID-19 pandemic, during which many schools were closed for a year or more, " +
                "led some parents to explore other options, from private schools to microschools to homeschooling, and many families have not " +
                "returned to the public system.\n \nOne of the most radical departures from traditional schooling is an approach known as unschooling." +
                "\n \nUnschooling is an educational philosophy that relies on a child’s innate curiosity and desire to learn. In families that practice " +
                "unschooling, students do not attend school and do not follow any set homeschool curriculum.",
                "28/12/2022",R.drawable.news5_img,"Education");
        newsArrayList.add(news5);

        //Education
        News news9 = new News(7,"Target the Right Reach Law Schools","Law school admissions decisions are based on numerous factors. " +
                "Historically, strong undergraduate grades and high scores on the Law School Admission Test, commonly referred to as the LSAT, have been " +
                "chief among them.\n \nBut applicants whose numbers don't match those of their dream schools still have a chance to prove themselves " +
                "in other ways. Soft factors like life and work experience, extracurricular involvement, diverse backgrounds, leadership positions " +
                "held and the quality of recommendation letters can help law schools determine if an applicant is a good investment.",
                "30/12/2022",R.drawable.news9_img,"Education");
        newsArrayList.add(news9);

        return newsArrayList;
    }

    public static List<News> getHealthNews() {

        List<News> newsArrayList = new ArrayList<>();

        //Health
        News news7 = new News(8,"Here’s How Early the Flu Has Struck This Year","A look at historical data shows the 2022-2023 flu season is " +
                "off to a dramatic start, with the weekly hospitalization rate 20 times higher than at the same time last season.\n \n" +
                "The Centers for Disease Control and Prevention tracks flu hospitalization rates using the Influenza Hospitalization Surveillance " +
                "Network, which currently collects data from more than 70 counties across 13 states and represents nearly 30 million people, or 9% " +
                "of the U.S. population. The CDC typically lists rates reflecting cases from early October to late April of the following year, " +
                "reporting figures for each “MMWR week.” The surveillance network’s dashboard reports weekly hospitalization rates from the 2009-2010 " +
                "through the 2022-2023 seasons, except for the 2020-2021 season, when there was extremely low flu activity amid the COVID-19 pandemic.",
                "9/12/2022",R.drawable.news7_img,"Health");
        newsArrayList.add(news7);

        //Health
        News news11 = new News(9,"Drug Approved to Help Young Patients Battle a Rare Cancer","Children and adults with a rare type of soft tissue cancer" +
                "will now have a new treatment option that could have a big impact.\n \nThe U.S. Food and Drug Administration has approved the immunotherapy " +
                "drug atezolizumab (Tecentriq) for use in patients with advanced alveolar soft part sarcoma (ASPS) that has spread to other parts of the body " +
                "or cannot be removed by surgery.",
                "2/1/2023",R.drawable.news11_img,"Health");
        newsArrayList.add(news11);

        return newsArrayList;
    }

    public static List<News> getTechnologyNews() {

        List<News> newsArrayList = new ArrayList<>();

        //Technology
        News news3 = new News(10,"Tech Firms Took a Beating in 2022 as Consumers Changed Their Buying Habits","The lockdowns created " +
                "tech superstars, but now the companies are the economy’s ugly ducklings.\n \nAt the height of the coronavirus in 2020 " +
                "and then as the pandemic lingered into 2021, Americans turned to the web to conduct their daily affairs. /n " +
                "They shopped via Instacart, they attended office meetings via Zoom, they ordered truckloads of goods from Amazon, " +
                "binged Netflix in their after hours, and a small minority found time to ride indoors on a Peloton.\n \n" +
                "The result: the business and stock market performance of those companies soared as consumers embraced the idea that " +
                "a new era of interconnectedness had dawned.",
                "30/12/2022",R.drawable.news3_img,"Technology");
        newsArrayList.add(news3);

        //Technology
        News news10 = new News(11,"India Proposes Self-Regulatory Bodies for Online Gaming Companies","NEW DELHI (Reuters) -India has proposed a " +
                "body for the online gaming industry to regulate itself as concerns rise over the addictiveness of games and as patchy state laws disrupt " +
                "business, in draft amendments to its information technology rules published on Monday.\n \nThe proposal comes after a government panel " +
                "recommended new rules to regulate a sector estimated to reach $7 billion by 2026, according to consultancy Redseer.",
                "2/1/2023",R.drawable.news10_img,"Technology");
        newsArrayList.add(news10);

        return newsArrayList;
    }
}
