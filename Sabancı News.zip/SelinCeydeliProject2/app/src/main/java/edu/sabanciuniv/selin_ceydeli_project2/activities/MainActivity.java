package edu.sabanciuniv.selin_ceydeli_project2.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import edu.sabanciuniv.selin_ceydeli_project2.adapters.MyFragmentAdapter;
import edu.sabanciuniv.selin_ceydeli_project2.R;

public class MainActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager2 viewPager2;
    MyFragmentAdapter frgAdp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Changing the action bar title in the Main Activity
        getSupportActionBar().setTitle("CS310 News");

        //Adding a home icon to the action bar
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_baseline_home_24);// set drawable icon
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Displaying tabs for each news category
        tabLayout = findViewById(R.id.tabLayout);
        viewPager2 = findViewById(R.id.viewPager2);
        frgAdp = new MyFragmentAdapter(this);
        viewPager2.setAdapter(frgAdp);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                tabLayout.getTabAt(position).select();
            }

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                tabLayout.setScrollPosition(position, positionOffset, true);
            }
        });

    }
}