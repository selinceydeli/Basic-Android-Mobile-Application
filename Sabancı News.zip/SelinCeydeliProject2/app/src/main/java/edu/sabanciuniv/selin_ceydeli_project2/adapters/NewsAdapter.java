package edu.sabanciuniv.selin_ceydeli_project2.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.sabanciuniv.selin_ceydeli_project2.R;
import edu.sabanciuniv.selin_ceydeli_project2.activities.NewsDetailActivity;
import edu.sabanciuniv.selin_ceydeli_project2.models.News;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {

    Context ctx;
    List<News> data;

    //constructor
    public NewsAdapter(Context ctx, List<News> data) {
        this.ctx = ctx;
        this.data = data;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //This method is called when the row is displayed for the first time on the screen.
        View row = LayoutInflater.from(ctx).inflate(R.layout.news_row_layout,parent,false);
        NewsViewHolder viewHolder = new NewsViewHolder(row);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        //This method is called whenever the user displays a certain row for the second time.
        //Data is filled by using the position given
        News current = data.get(position);
        holder.img.setImageResource(current.getImg());
        holder.title.setText(current.getTitle());
        holder.date.setText(current.getDate());

        //An interaction with the screen -> clickable
        holder.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ctx, NewsDetailActivity.class);
                i.putExtra("selectedRow",current);
                ctx.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class NewsViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView date;
        ImageView img;
        ConstraintLayout row;

        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.txtNewsTitle);
            date = itemView.findViewById(R.id.txtDate);
            img = itemView.findViewById(R.id.imgRowNews);
            row = itemView.findViewById(R.id.row);
        }
    }

}
