package edu.sabanciuniv.selin_ceydeli_project2.models;

import java.io.Serializable;

public class Comments implements Serializable {

    private int id;
    private String news_id;
    private String name;
    private String text;

    public Comments() {}

    public Comments(int id, String newsId, String ownerName, String message) {
        this.id = id;
        this.news_id = newsId;
        this.name = ownerName;
        this.text = message;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNewsId() {
        return news_id;
    }

    public void setNewsId(String newsId) {
        this.news_id = newsId;
    }

    public String getOwnerName() {
        return name;
    }

    public void setOwnerName(String ownerName) {
        this.name = ownerName;
    }

    public String getMessage() {
        return text;
    }

    public void setMessage(String message) {
        this.text = message;
    }
}
